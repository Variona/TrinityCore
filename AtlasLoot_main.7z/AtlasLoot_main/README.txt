These files need to go into your World of Warcraft Wrath of the Lich King (3.3.5) addon folder.

It should look something like: "\World of Warcraft\Interface\Addons"

Put the following folders inside the Addons folder.

AtlasLoot
AtlasLoot_BurningCrusade
AtlasLoot_Crafting
AtlasLoot_OriginalWoW
AtlasLoot_WorldEvents
AtlasLoot_WrathoftheLichKing
AtlasLootFu

Replace any files if you have an older version.

This version is for my custom server only. The changes will not work properly if you don't
	play on my custom realm.
	
-- Variona
https://github.com/Variona/TrinityCore/